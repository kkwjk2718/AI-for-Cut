#include <bnb/texture_bicubic.glsl>

float hair_mask(BNB_DECLARE_SAMPLER_2D_ARGUMENT(tex_mask), vec2 uv)
{
    vec4 mask = bnb_texture_bicubic(BNB_PASS_SAMPLER_ARGUMENT(tex_mask), uv);

    return mask.x;
}

/* returns index of the color to be used in [0-4] range */
float strands_mask(BNB_DECLARE_SAMPLER_2D_ARGUMENT(tex_mask), vec2 uv)
{
    vec4 mask = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex_mask), uv);

    // the strands mask consist of bytes of *integers* in [0-4] range
    // since the bytes are fetched as *floats*, we have to multiply them by 255 to get the integers back
    mask *= 255.;

    return mask.x;
}
