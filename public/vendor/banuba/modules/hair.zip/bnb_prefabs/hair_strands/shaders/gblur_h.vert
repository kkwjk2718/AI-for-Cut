#include <bnb/glsl.vert>

BNB_LAYOUT_LOCATION(0)
BNB_IN vec3 attrib_pos;
BNB_OUT(0)
vec2 v_tex_coord;

void main()
{
    vec2 v = attrib_pos.xy;
    gl_Position = vec4(v, 1.0, 1.0);
    v_tex_coord = v * 0.5 + 0.5;

#ifdef BNB_VK_1
    v_tex_coord.y = 1. - v_tex_coord.y;
#endif
}
