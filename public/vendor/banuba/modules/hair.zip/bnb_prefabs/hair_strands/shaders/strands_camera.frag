#include <bnb/glsl.frag>
#include "bnb_prefabs/hair_strands/shaders/filtered_mask.glsl"
#include "bnb_prefabs/hair_strands/shaders/yuv.glsl"

BNB_IN(0)
vec2 var_uv;
BNB_IN(1)
vec2 var_hair_mask_uv;
BNB_IN(2)
vec2 var_strands_mask_uv;

BNB_DECLARE_SAMPLER_2D(0, 1, tex_camera);
BNB_DECLARE_SAMPLER_2D(2, 3, tex_hair_mask);
BNB_DECLARE_SAMPLER_2D(4, 5, tex_strands_mask);

vec4 color(vec4 base, vec4 target, float alpha)
{
    const float beta = 0.5;

    vec3 pixel1 = rgb2yuv(base.rgb);
    vec3 yuv1 = rgb2yuv(target.rgb);
    float y_norm = 1.f / 0.5f;
    pixel1[0] = pixel1[0] * (yuv1[0] * y_norm);
    pixel1[1] = mix(pixel1[1], mix(pixel1[1], yuv1[1], beta), alpha);
    pixel1[2] = mix(pixel1[2], mix(pixel1[2], yuv1[2], beta), alpha);

    return vec4(yuv2rgb(pixel1), target.a);
}

void main()
{
    float mask = hair_mask(BNB_PASS_SAMPLER_ARGUMENT(tex_hair_mask), var_hair_mask_uv);
    vec4 camera = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex_camera), var_uv);
    vec4 target_color = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex_strands_mask), var_uv);
    vec4 colored = color(camera, target_color, mask);

    bnb_FragColor = vec4(colored.rgb, colored.a * mask);
}
